<?php
session_start();
include_once '../connect.php';

if (!isset($_SESSION['email'])) {
    header('location:login.php');
}

$sql = "SELECT * FROM birthform";
$result = $conn->query($sql);
$users = $result->fetch_all(MYSQLI_ASSOC); // to fetch all the data from database.

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate of Birth</title>
    <style>
               body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f5f5f5;
        }
        .certificate-container {
            background-color: white;
            border: 1px solid #ddd;
            width: 600px;
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .certificate-container h2 {
            text-align: center;
            margin-top: 0;
        }
        .details-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .details-table th, .details-table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        .details-table th {
            background-color: #f9f9f9;
            width: 30%;
        }


        /* Print and Download Button */
        .action-buttons {
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
        }

        .btn {
            display: inline-block;
            width: 48%;
            padding: 12px;
            font-size: 16px;
            text-align: center;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn-print {
            background-color: #28a745;
        }

        .btn-print:hover {
            background-color: #218838;
        }

        .btn-download {
            background-color: #007bff;
        }

        .btn-download:hover {
            background-color: #0056b3;
        }

        /* Print View */
        @media print {
            body {
                background-color: white;
                margin: 0;
            }

            .certificate-container {
                box-shadow: none;
                border: none;
            }

            .action-buttons {
                display: none;
            }
        }
    </style>
</head>

<body>
    <div class="certificate-container">
        <h2>Certificate of Birth</h2>
        <p>This is to certify that the following information has been taken from the official record of Birth.</p>
        
        <?php if (!empty($users)) : ?>
        <table class="details-table">
            <thead>
                <tr>
                    <th>Application Number</th>
                    <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['member_id'], ENT_QUOTES, 'UTF-8'); ?></td>
                </tr>
                <?php endforeach; ?>
                    </tbody>
                    <th>Full Name</th>
                    <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['First_name'] . ' ' . $user['Last_name'], ENT_QUOTES, 'UTF-8'); ?></td>
                </tr>
                <?php endforeach; ?>
                    </tbody>
                    <th>Gender</th>   <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['Gender'], ENT_QUOTES, 'UTF-8'); ?></td>
                </tr>
                <?php endforeach; ?>
                    </tbody>
                    <th>Date of Birth</th>
                    <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['Dateofbirth'], ENT_QUOTES, 'UTF-8'); ?></td>
                </tr>
                <?php endforeach; ?>
                    </tbody>
                    <th>Place of Birth</th>
                    <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['Birthplace'], ENT_QUOTES, 'UTF-8'); ?></td>
                </tr>
                <?php endforeach; ?>
                    </tbody>
                    <th>Mother's Name</th>
                    <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['Mother_name'], ENT_QUOTES, 'UTF-8'); ?></td>
                </tr>
                <?php endforeach; ?>
                    </tbody>
                    <th>Father's Name</th>
                    <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['Father_name'], ENT_QUOTES, 'UTF-8'); ?></td>
                </tr>
                <?php endforeach; ?>
                    </tbody>
                    <th>Permanent Address</th>
                    <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['permanent'], ENT_QUOTES, 'UTF-8'); ?></td>
                </tr>
                <?php endforeach; ?>
                    </tbody>
                    <th>Postal Address</th>
                    <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['postal'], ENT_QUOTES, 'UTF-8'); ?></td>
                </tr>
                <?php endforeach; ?>
                    </tbody>
                    <!-- <th>Guardian's Name</th>
                    <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['guardian'], ENT_QUOTES, 'UTF-8'); ?></td>
                </tr>
                <?php endforeach; ?>
                    </tbody>
                    <th>Relationship to Guardian</th>
                    <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?php echo htmlspecialchars($user['rela_guardian'], ENT_QUOTES, 'UTF-8'); ?></td>
                </tr>
                <?php endforeach; ?>
                    </tbody>
                </tr> -->
            </thead>
            
        </table>
        <?php else : ?>
        <p>No records found.</p>
        <?php endif; ?>

        <div class="action-buttons">
            <!-- <a href="certificate_download.php" class="btn btn-download">Download Certificate</a> -->
            <button onclick="window.print()" class="btn btn-print">Print Certificate</button>
        </div>
    </div>
</body>

</html>
