<!-- <?php
session_start();
include_once '../connect.php';

if (!isset($_SESSION['email'])) {
    header('location:login.php');
}

$sql = "SELECT * FROM birthform";
$result = $conn->query($sql);
$users = $result->fetch_all(MYSQLI_ASSOC); // to fetch all the data from database.

?> -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Table</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f8f9fa;
        }

        h2 {
            color: #333;
            text-align: center;
        }

        table {
            width: 100%;
            max-width: 1200px;
            margin: 20px auto;
            border-collapse: collapse;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            background-color: #ffffff;
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            padding: 15px;
            text-align: left;
        }

        th {
            background-color: #343a40;
            color: #ffffff;
            font-weight: 600;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #e9ecef;
        }

        .action-button {
            background-color: #28a745;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .action-button:hover {
            background-color: #218838;
        }

        @media (max-width: 768px) {
            table {
                width: 100%;
                font-size: 14px;
            }

            th, td {
                padding: 10px;
            }

            .action-button {
                font-size: 12px;
                padding: 6px 10px;
            }
        }
    </style>
</head>
<body>

<h2>Application Table</h2>

<table>
    <thead>
    <tr>
        <th>S.No</th>
        <th>Application Number</th>
        <th>Name</th>
        <th>Father's Name</th>
        <th>Mother's Name</th>
        <th>Status</th>
        <th>Action</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($users as $index => $eachuser): ?>
    <tr>
        <td><?php echo $index + 1; ?></td>
        <td><?php echo htmlspecialchars($eachuser['member_id'], ENT_QUOTES, 'UTF-8'); ?></td>
        <td><?php echo htmlspecialchars($eachuser['First_name'] . ' ' . $eachuser['Last_name'], ENT_QUOTES, 'UTF-8'); ?></td>
        <td><?php echo htmlspecialchars($eachuser['Father_name'], ENT_QUOTES, 'UTF-8'); ?></td>
        <td><?php echo htmlspecialchars($eachuser['Mother_name'], ENT_QUOTES, 'UTF-8'); ?></td>
        <td><?php echo htmlspecialchars($eachuser['status'], ENT_QUOTES, 'UTF-8'); ?></td>
        <td>
            <a href="./birthcertificate.php? id=<?php echo urlencode($eachuser['member_id']); ?>" class="action-button">View Details</a>
        </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>

</body>
</html>
