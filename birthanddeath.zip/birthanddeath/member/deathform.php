<?php

include '../connect.php';

// session_start();

// if(!isset($_SESSION['email'])){
//    header('location:login.php');
// }

$fnameErr = $lnameErr = $genderErr = $dateofbirthErr = $dateofdeathErr = $ageErr = $causeErr = $permanentErr = $postalErr = $guardianErr = $rela_guardianErr = "";
$fname = $lname = $gender = $dateofbirth = $dateofdeath = $age = $cause = $permanent = $postal = $guardian = $rela_guardian = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //validation
    if (empty($_POST["fname"])) {
        $fnameErr = "First name is required";
    } else {
        $fname = input($_POST["fname"]);
    }
    if (empty($_POST['lname'])) {
        $lnameErr = "Last name required or invalid";
    } else {
        $lname = input($_POST["lname"]);
    }
    if (empty($_POST['gender'])) {
        $genderErr = "Gender required or invalid";
    } else {
        $gender = input($_POST["gender"]);
    }
    if (empty($_POST['dateofbirth'])) {
        $dateofbirthErr = "Date of birth required or invalid";
    } else {
        $dateofbirth = input($_POST["dateofbirth"]);
    }
    if (empty($_POST['dateofdeath'])) {
        $dateofdeathErr = "Date of death required or invalid";
    } else {
        $dateofdeath = input($_POST["dateofdeath"]);
    }
    if (empty($_POST['age'])) {
        $ageErr = "age required or invalid";
    } else {
        $age = input($_POST["age"]);
    }
    if (empty($_POST['cause'])) {
        $causeErr = "cause required or invalid";
    } else {
        $cause = input($_POST["cause"]);
    }
    if (empty($_POST['permanent'])) {
        $permanentErr = "permanent required or invalid";
    } else {
        $permanent = input($_POST["permanent"]);
    }
    if (empty($_POST['postal'])) {
        $postalErr = "postal required or invalid";
    } else {
        $postal = input($_POST["postal"]);
    }
    if (empty($_POST['guardian'])) {
        $guardianErr = "guardian name required or invalid";
    } else {
        $guardian = input($_POST["guardian"]);
    }
    if (empty($_POST['rela_guardian'])) {
        $rela_guardianErr = "rela_guardian required or invalid";
    } else {
        $rela_guardian = input($_POST["rela_guardian"]);
    }



    if ($fname != "" && $lname != "" && $gender != "" && $dateofbirth != "" && $dateofdeath != "" && $age != "" && $cause != "" && $permanent != "" && $postal != "" && $guardian != "" && $rela_guardian != "") {
        $sql = "INSERT INTO deathform (fname, lname, gender, dateofbirth, dateofdeath, age, cause, permanent, postal, guardian, rela_guardian) 
        VALUES ('$fname', '$lname', '$gender', '$dateofbirth', '$dateofdeath', '$age', '$cause', '$permanent', '$postal','$guardian', '$rela_guardian')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>
            alert('We have received your request...We will contact you soon!');
            window.location = 'homepage.php';
            </script>";
        } else {
            echo "Data insert Failed.";
        }
    }
}
function input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/birth.css">
    <title>Death</title>
</head>

<body>

    <div class="container">
        <button type="Submit" class=button><a href="homepage.php">BACK</a>
        </button>
        <h1>Death Form</h1>
        <div class="box">
            <form action="deathform.php" method="POST">

                <label for="fname">First Name*</label>
                <input type="text" id="fname" name="fname" placeholder="Enter first name..."><br><br>

                <label for="lname">Last Name*</label>
                <input type="text" id="lname" name="lname" placeholder="Enter last name..."><br><br>

                <label for="gender">Gender*</label>
                <input type="radio" id="male" name="gender" value="Male">
                <label for="male">Male</label>
                <input type="radio" id="female" name="gender" value="Female">
                <label for="female">Female</label><br><br>

                <label for="dateofbirth">Date of Birth:</label>
                <input type="date" id="dateofbirth" name="dateofbirth"><br><br>

                <label for="dateofdeath">Date of Death:</label>
                <input type="date" id="dateofdeath" name="dateofdeath"><br><br>

                <label for="age">Age</label>
                <input type="number" name="age" value=""><br><br>

                <label for="cause">Causes of Death</label>
                <input type="text" id="cause" name="cause" placeholder="Enter cause of death"><br><br>

                <label for="permanent">Permanent Address</label>
                <input type="text" id="permanent" name="permanent" placeholder="permanent"><br><br>



                <label for="postal">Postal Address</label>
                <input type="text" id="postal" name="postal" placeholder="postal"><br><br>

                <label for="guardian">Family member who provided the details of death</label>
                <input type="text" id="guardian" name="guardian" placeholder="Enter name of the family member..."><br><br>

                <label for="rela_guardian">Relationship with death person</label>
                <input type="text" id="rela_guardian" name="rela_guardian" placeholder="Enter relationship with death person..."><br><br>

                <button type="submit" class="button">Submit</button>

            </form>
        </div>
    </div>
</body>

</html>