<?php
session_start();
include '../connect.php';

if (!isset($_SESSION['email'])) {
    header('location:login.php');
}

// Initialize variables and error messages
$First_nameErr = $Last_nameErr = $Father_nameErr = $Mother_nameErr = $GenderErr = $DateofbirthErr = $BirthplaceErr = $permanentErr = $postalErr = $guardianErr = $rela_guardianErr = "";
$First_name = $Last_name = $Father_name = $Mother_name = $Gender = $Dateofbirth = $Birthplace = $permanent = $postal = $guardian = $rela_guardian = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate inputs
    if (empty($_POST["First_name"])) {
        $First_nameErr = "First name is required";
    } else {
        $First_name = input($_POST["First_name"]);
    }

    if (empty($_POST["Last_name"])) {
        $Last_nameErr = "Last name is required";
    } else {
        $Last_name = input($_POST["Last_name"]);
    }

    if (empty($_POST["Father_name"])) {
        $Father_nameErr = "Father's name is required";
    } else {
        $Father_name = input($_POST["Father_name"]);
    }

    if (empty($_POST["Mother_name"])) {
        $Mother_nameErr = "Mother's name is required";
    } else {
        $Mother_name = input($_POST["Mother_name"]);
    }

    if (empty($_POST["Gender"])) {
        $GenderErr = "Gender is required";
    } else {
        $Gender = input($_POST["Gender"]);
    }

    if (empty($_POST["Dateofbirth"])) {
        $DateofbirthErr = "Date of Birth is required";
    } else {
        $Dateofbirth = input($_POST["Dateofbirth"]);
    }

    if (empty($_POST["Birthplace"])) {
        $BirthplaceErr = "Birthplace is required";
    } else {
        $Birthplace = input($_POST["Birthplace"]);
    }

    if (empty($_POST["permanent"])) {
        $permanentErr = "Permanent address is required";
    } else {
        $permanent = input($_POST["permanent"]);
    }

    if (empty($_POST["postal"])) {
        $postalErr = "Postal address is required";
    } else {
        $postal = input($_POST["postal"]);
    }

    if (empty($_POST["guardian"])) {
        $guardianErr = "Guardian name is required";
    } else {
        $guardian = input($_POST["guardian"]);
    }

    if (empty($_POST["rela_guardian"])) {
        $rela_guardianErr = "Relationship with guardian is required";
    } else {
        $rela_guardian = input($_POST["rela_guardian"]);
    }

    $member_id = $_SESSION['member_id'] ?? null;
    if (!$member_id) {
        die("Error: member_id is missing. Please log in again.");
    }
    // Insert into the database if no errors
    if ($First_nameErr == "" && $Last_nameErr == "" && $Father_nameErr == "" && $Mother_nameErr == "" && $GenderErr == "" && $DateofbirthErr == "" && $BirthplaceErr == "" && $permanentErr == "" && $postalErr == "" && $guardianErr == "" && $rela_guardianErr == "") {

        $sql = "INSERT INTO birthform (member_id, First_name, Last_name, Father_name, Mother_name, Gender, Dateofbirth, Birthplace, permanent, postal, guardian, rela_guardian) 
                VALUES ('$member_id', '$First_name', '$Last_name', '$Father_name', '$Mother_name', '$Gender', '$Dateofbirth', '$Birthplace', '$permanent', '$postal', '$guardian', '$rela_guardian')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>
                alert('We have received your request...We will contact you soon!');
                window.location = 'homepage.php';
            </script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

function input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/birth.css">
    <title>Birth</title>
</head>

<body>

    <div class="container">
    <button type="Submit" class= button><a href="homepage.php">BACK</a>
    
    </button>
        <h1> Birth Form</h1>
        <div class="box">
            <form action="birthform.php" method="POST" enctype="multipart/form-data">
            
    
    </button>
                <label for="First_name">First Name*</label>
                <input type="text" id="First_name" name="First_name" placeholder="Enter First name...."><br><br>

                <label for="Last_name">Last Name*</label>
                <input type="text" id="Last_name" name="Last_name" placeholder="Enter Last name.."><br><br>

                <label for="Father_name">Father name*</label>
                <input type="text" id="Father_name" name="Father_name" placeholder="Enter Father name.."><br><br>

                <label for="Mother_name">Mother name*</label>
                <input type="text" id="Mother_name" name="Mother_name" placeholder="Enter Mother name.."><br><br>
                <label for="Gender">Gender*</label>
                <input type="radio" id="male" name="Gender" value="Male">
                <label for="male">Male</label>
                <input type="radio" id="female" name="Gender" value="Female">
                <label for="female">Female</label><br><br>


                <label for="Dateofbirth">Date of Birth:</label>
                <input type="date" id="Dateofbirth" name="Dateofbirth"><br><br>

                <label for="Birthplace">Birth Place</label>
                <select id="Birthplace" name="Birthplace">
                <option value="Hospital">Hospital</option>
                    <option value="Home">Home</option>
                    <option value="Health Department">Health Department</option>
                    </select><br><br>
                <label for="permanent">Permanent Address</label>
                <input type="text" id="permanent" name="permanent" placeholder="permanent"><br><br>

             

                <label for="postal">Postal Address</label>
                <input type="text"  id="postal" name="postal" placeholder="postal"><br><br>
                
                <label for="guardian">Guardian</label>
                <input type="text" id="guardian" name="guardian" placeholder="Enter guardian name.."><br><br>
                <label for="rela_guardian">Relationship with guardian</label>
                <input type="text" id="rela_guardian" name="rela_guardian" placeholder="Relationship with guardian.."><br><br>
                
                <button type="Submit" class="button">Submit
                </button>
                
            </form>
        </div>
    </div>
</body>

</html>