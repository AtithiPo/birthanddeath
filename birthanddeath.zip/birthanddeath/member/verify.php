<?php
include '../connect.php'; // connect database

if (isset($_GET['email']) && isset($_GET['token'])) {
    $email = $_GET['email'];
    $token = $_GET['token'];

    // Check if the token matches the email in the database
    $sql = "SELECT * FROM member WHERE email='$email' AND verifytoken='$token'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Update user status to verified
        $update_sql = "UPDATE member SET verifiedtoken=1, verifytoken=NULL WHERE email='$email'";
        if ($conn->query($update_sql) === TRUE) {
            echo "Email verification successful! You can now <a href='login.php'>login</a>.";
        } else {
            echo "Verification failed. Please try again.";
        }
    } else {
        echo "Invalid verification link.";
    }
}
?>
