<?php
// Start a session and include database connection
session_start();
include '../connect.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Online system for requesting and managing birth and death certificates.">
    <title>Online Birth and Death Register</title>

    <!-- Bootstrap 5.3.3 CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    
    <!-- Custom Styles -->
    <style>
        /* Body styling */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f2f5;
        }

        /* Container styling */
        .container {
            margin: 0 auto;
        }

        /* Banner Section */
        .banner {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 60vh;
            background-image: linear-gradient(to bottom right, #007bff, #0056b3);
            color: #ffffff;
            text-align: center;
        }

        .app-text {
            max-width: 600px;
        }

        .app-text h1 {
            font-size: 3rem;
            margin-bottom: 0.5rem;
        }

        .app-text h2 {
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .app-text a {
            display: inline-block;
            margin: 10px;
            padding: 12px 25px;
            background-color: #28a745;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }

        .app-text a:hover {
            background-color: #218838;
        }
    </style>
</head>

<body>
    <div class="container">
        <!-- Navbar Section -->
        <?php include 'navbar.php'; ?>

        <!-- Banner Section -->
        <div class="banner">
            <div class="app-text">
                <h1>Online Birth and Death</h1>
                <h2>Certificate Request System</h2>

                <?php if (isset($_SESSION['email'])): ?>
                    <h3>Select the form to fill:</h3>
                    <a href="./birthform.php">Birth Certificate Request</a>
                    <a href="./deathform.php">Death Certificate Request</a>

                    <h3>View the details:</h3>
                    <a href="./birthviewas.php">Birth Certificate Detail</a>
                    <a href="./deathviewas.php">Death Certificate Detail</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5.3.3 JavaScript CDN -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>
