<?php
include '../connect.php';
 

if(isset($_GET['member_id'])){

$member_id = $_GET['member_id'];

$query ="DELETE from member WHERE member_id='$member_id'";

$result = mysqli_query($conn,$query);
if($result){
    echo '<script> alert("Data Deleted")</script>';
    header('location:list_member.php');


}else{
    echo '<script> alert("Data delete Fail")</script>';
   
}
}


?>