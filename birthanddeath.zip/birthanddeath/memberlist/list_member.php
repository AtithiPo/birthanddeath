<?php
session_start();
include_once '../connect.php';

if (!isset($_SESSION['email'])) {
    header('location:login.php');
}

$sql = "SELECT * FROM member";
$result = $conn->query($sql);
$users = $result->fetch_all(MYSQLI_ASSOC); // to fetch all the data from database.

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,
				initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/responsive.css">
    <link rel="stylesheet" href="../css/table.css">
</head>

<body>

    <header>

        <div class="logosec">
            <div class="logo">Admin</div>
            <img src="../image/3_line.png" class="icn menuicn" id="menuicn" alt="menu-icon">
        </div>

        <div class="searchbar">
            <input type="text" placeholder="Search">
            <div class="searchbtn">
                <img src="../image/search.png" class="icn srchicn" alt="search-icon">
            </div>
        </div>

        <div class="message">
            <div class="circle"></div>
            <img src="image/notification.png" class="icn" alt="">
            <div class="dp">
                <img src="i../mage/profile.png" class="dpicn" alt="dp">
            </div>
        </div>

    </header>

    <div class="main-container">
        <div class="navcontainer">
            <nav class="nav">
                <?php include('../user/side_bar.php')  ?>

            </nav>
        </div>
        <div class="main">

            <div class="searchbar2">
                <input type="text" name="" id="" placeholder="Search">
                <div class="searchbtn">
                    <img src="image/search_icon.png" class="icn srchicn" alt="search-button">
                </div>
            </div>

            <button>
                <a href="../registration.php">Add member</a></button>
            <div class="user">
                <table>
                    <thead>
                        <tr>
                            <th>S.N</th>
                            <th>fullname</th>
                            <th>email</th>
                            <th>action</th>
                     
                        </tr>
                    </thead>


                    <tbody>
                        <?php foreach ($users as $index => $eachuser) { ?>
                            <tr>
                                <td><?php echo $index + 1 ?></td>
                                <td><?php echo $eachuser['full_name'] ?></td>
                                <td><?php echo $eachuser['email'] ?></td>
                              
                                
                                <td>
                                <!-- <a href="edit_member.php">Edit</a>
                                        <a onclick="deleteFunction()" href="delete_member.php">Delete</a>  -->
                                    <a href="edit_member.php?member_id=<?php echo $eachuser['member_id'] ?>">Edit</a>
                                    <a onclick="deleteFunction()" href="delete_member.php?member_id=<?php echo $eachuser['member_id'] ?>">Delete</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>


                </table>



            </div>

            <script>
                    function deleteFunction(){
                        confirm("Are you sure you want to delete?");
                    }
                </script>

            <script src="Js/index.js"></script>
</body>

</html>