<?php

include '../connect.php';
if(is_numeric($member_id =$_GET['member_id'])){
  $member_id =$_GET['member_id'];
} else{
  header('location:list_member.php');
}


$qury="SELECT * FROM member WHERE member_id='$member_id'";
$result = $conn->query($qury);
$row = $result->fetch_assoc(); 



if(isset($_POST['submit'])){
$fullname =  $_POST['ful_name'];
$email = $_POST['email'];
$sql ="UPDATE member SET full_name='$full_name',email='$email' WHERE member_id= '$member_id'";
$result=mysqli_query($conn,$sql);
print_r($result);
if($result){
  //echo '<script> alert("Data Update")</script>';
  echo '<script> window.alert("Succesfully Updated");
  window.location.replace("list_member.php");
  </script>';

}else{
  echo '<script> alert("Data Update Fail")</script>';
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update page</title>
    <link rel="stylesheet" href="../Css/styles.css">
</head>
<body> 
    <form action="update.php?id=<?php echo $row['member_id'] ?>" method="POST">
    <div class="submenu">

    <label for="full_name">Full Name</label>
            <input type="text" id="fname" name="full_name" value= "<?php echo  $row['full_name'];?>" placeholder="Enter Name">
  
   
            <label for="email">E-mail</label>
            <input type="text" id="lname" name="email" value="<?php echo $row['email']; ?>" placeholder="Your Email">


 
    <button type="submit" class="registerbtn"  name="submit">Update</button>
  </div>
</form>
</body>
</html>
