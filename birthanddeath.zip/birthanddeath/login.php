<?php
session_start();
if (isset($_SESSION['email'])) {
    header('location:dashboard.php');
}
include 'connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM admin WHERE email = '$email'";

    $result = $conn->query($sql);
    $users = $result->fetch_assoc();

    if ($result && $result->num_rows > 0) {
        if (password_verify($password, $users['password'])) {

            $_SESSION['email'] = $email;

            header('location:dashboard.php');
        } else {
            echo "Invalid Password.";
        }
    } else {
        echo "Email not Found.";
    }
}

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/login.css">
    <title>First page</title>
</head>

<body>

    <div class="form_container">

        <form class="d-flex justify-content-center" action="login.php" method="post">
            <h2> Login</h2>

            <div class="input_box">
                <label for="email" class="form-label">E-mail</label>
                <input type="email" name="email" class="form-control" id="email" value="">

            </div>
            <div class="input_box">
                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" class="form-control" id="password" value="">
            </div>
            <div class="option_field">
                
                <button class="button">Login Now</button>
            </div>

            <p><span style="color: rgb (201, 195, 195);"> Doesn't have account <a href="registration.php">Registration now </a></span></p>
    </div>
    </form>

</body>

</html>