<!-- for header part -->
<link rel="stylesheet" href="./css/styles.css">
<link rel="stylesheet" href="./css/responsive.css">
<header>

    <div class="logosec">
        <div class="logo">Admin</div>
        <img src="image/3_line.png" class="icn menuicn" id="menuicn" alt="menu-icon">
    </div>

    <div class="searchbar">
        <input type="text" placeholder="Search">
        <div class="searchbtn">
            <img src="image/search_icon.png" class="icn srchicn" alt="search-icon">
        </div>
    </div>

    <div class="message">
        <div class="circle"></div>
        <img src="image/notification.png" class="icn" alt="">
        
        <div class="dp">
            <img src="image/profile.png" class="icn" alt="">
        </div>
    </div>

</header>
<script src="../Js/index.js"></script>