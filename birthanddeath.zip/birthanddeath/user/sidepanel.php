<link rel="stylesheet" href="../css/styles.css">


<div class="nav-upper-options">
	<div class="nav-option option1">
		<img src="image/dashboardicon.png" class="nav-img" alt="dashboard">
		<h3> Home</h3>
	</div>

	<div class="option2 nav-option">
		<img src="./image/userlist.png" class="nav-img" alt="articles">
		<a href="./partial/list.php">
			<h4> User</h4>
		</a>
	</div>
	<div class="nav-option option5">
		<img src="image/10.png" class="nav-img" alt="blog">
		<h3> Birth</h3>
	</div>
	<div class="nav-option option5">
		<img src="image/10.png" class="nav-img" alt="blog">
		<h3> Death</h3>
	</div>


	<div class="nav-option logout">
		<img src="image/logout.png" class="nav-img" alt="logout">
		<a href="logout.php">
			<h3>Logout</h3>
		</a>
	</div>

</div>