<?php
$protocol = isset($_SERVER['HTTPS']) ? 'https' : 'http';
$server_name = $_SERVER['SERVER_NAME'];
$url = $protocol . "://" . $server_name . "/birthanddeath/";
?>

<link rel="stylesheet" href="../css/styles.css">


<div class="navcontainer">
    <nav class="nav">
        <div class="nav-upper-options">
            <div class="nav-option option1">

                <a href="<?php echo $url . 'dashboard.php' ?>">
                    <h2> <img src="<?php echo $url . 'image/dashboardicon.png' ?>" class="nav-img" alt="dashboard"> Dashboard</h2>
                </a>
            </div>

            <div class="nav-option option2">
                <a href="<?php echo $url . 'partial/list.php' ?>">
                    <h2> <img src="<?php echo $url . 'image/userlist.png' ?> " class="nav-img" alt="articles">Users</h2>
                </a>
            </div>

            <div class="nav-option option3">
                <a href="<?php echo $url . 'birth/birth_list.php' ?>">
                    <h2> <img src="<?php echo $url . 'image/userlist.png' ?>" class="nav-img" alt="report">Birth</h2>
            </div>
            <div class="nav-option option4">
                <a href="<?php echo $url . 'death/death_list.php' ?>">
                    <h2> <img src="<?php echo $url . 'image/userlist.png' ?>" class="nav-img" alt="report">Death</h2>
            </div>
            <div class="nav-option option5">
                <a href="<?php echo $url . 'memberlist/list_member.php' ?>">
                    <h2> <img src="<?php echo $url . 'image/userlist.png' ?> " class="nav-img" alt="articles">Member</h2>
                </a>
            </div>
            <div class="nav-option logout">

                <a href="<?php echo $url . 'logout.php' ?>">
                    <h2> <img src="<?php echo $url . 'image/logout.png' ?>" class="nav-img" alt="settings">Logout</h2>
                </a>
            </div>

        </div>
    </nav>
</div>