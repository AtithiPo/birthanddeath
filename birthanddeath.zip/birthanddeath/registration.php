<?php

include 'connect.php'; // conneect database

$full_nameErr = $emailErr = $passwordErr = "";
$full_name = $email = $password = "";

//data insert into database
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //validation
    if (empty($_POST["full_name"])) {
        $full_nameErr = "Full name is required";
    } else {
        $full_name = input($_POST["full_name"]);
    }
    if (empty($_POST['email'])) {
        $emailErr = "Email field required or invalid";
    } else {
        $email = input($_POST["email"]);
    }
    if (empty($_POST["password"])) {
        $passwordErr = "Password is required";
    } else {
        // password_verify('password', $hashpassword);
        $password = password_hash(input($_POST["password"]), PASSWORD_DEFAULT);
    }

    if ($full_nameErr == "" && $emailErr == "" && $passwordErr == "") {

        if (preg_match("/^[a-zA-z\s]*$/", $full_name)) {

            if (preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/", $email)) {

                if (strlen($_POST["password"]) >= '8') {

                    if (preg_match("#[0-9]+#", $password)) {

                        if (preg_match("#[A-Z]+#", $password)) {

                            if (preg_match("#[a-z]+#", $password)) {

                                if (preg_match('@[^\w]@', $password)) {


                                    $sql = "INSERT INTO admin (full_name, email, password)
       VALUES ('$full_name', '$email', '$password')";
                                    if ($conn->query($sql) ===  TRUE) {
                                        //echo "Data insert successsfully";
                                        header('location:login.php');
                                    } else {
                                        echo "Data insert Failed.";
                                    }
                                } else {
                                    echo "Your Password Must Contain At Least 1 special character!";
                                }
                            } else {
                                echo "Your Password Must Contain At Least 1 Lowercase Letter!";
                            }
                        } else {

                            echo "Your Password Must Contain At Least 1 Capital Letter!";
                        }
                    } else {
                        echo "Your Password Must Contain At Least 1 Number!";
                    }
                } else {
                    echo "Password must be at least 8 characters in length and must contain at least one number, one upper case letter, one lower case letter and
        one special character.";
                }
            } else {
                echo "You Entered An Invalid Email Format";
            }
        } else {
            echo "Only alphabets and whitespace are allowed.";
        }
    }
}




function input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/register.css">


</head>

<body>
    <div class="form_container">



        <form class="d-flex justify-content-center" action="registration.php" method="POST">
            <h2> Registrations</h2>

            <div class="input_box">
                <label for="full_name" class="form-label">Full Name</label>
                <input type="full_name" name="full_name" class="form-control" id="full_name" value="<?php $full_name ?>">
            </div>
            <div class="input_box">
                <label for="email" class="form-label">Email</label>
                <input type="text" name="email" class="form-control" id="email">


            </div>

            <div class="input_box">
                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" class="form-control" id="password">
                <span class="error"><?php $passwordErr ?></span>
            </div>

            <div class="option_field">
                <button class="button">Register Now</button>
            </div>

            <p><span style="color: rgb (201, 195, 195);"> Already have an account> <a href="login.php">login now </a></p>

        </form>
    </div>


</body>

</html>