<?php

include '../connect.php';
if(is_numeric($birth_id =$_GET['birth_id'])){
  $birth_id =$_GET['birth_id'];
} else{
  header('location:birth_list.php');
}


$qury="SELECT * FROM birthform WHERE birth_id='$birth_id'";
$result = $conn->query($qury);
$row = $result->fetch_assoc(); 




if(isset($_POST['submit'])){
$First_name =  $_POST['First_name'];
$Last_name =  $_POST['Last_name'];
$Father_name =  $_POST['Father_name'];
$Mother_name =  $_POST['Mother_name'];
$Gender =  $_POST['Gender'];
$Dateofbirth =  $_POST['Dateofbirth'];
$Birthplace =  $_POST['Birthplace'];
$premanent =  $_POST['premanent'];
$postal =  $_POST['postal'];

$guardian =  $_POST['guardian'];
$rela_guardian =  $_POST['rela_guardian'];

$sql ="UPDATE birthform SET First_name='$First_name', Last_name='$Last_name',Father_name='$Father_name',Mother_name='$Mother_name',Gender='$Gender',Dateofbirth='$Dateofbirth',Birthplace='$Birthplace',
premanent='$premanent',postal='$postal',guardian='$guardian', rela_guardian='$rela_guardian' WHERE birth_id= '$birth_id'";
$result=mysqli_query($conn,$sql);
print_r($result);
if($result){
  //echo '<script> alert("Data Update")</script>';
  echo '<script> window.alert("Succesfully Updated");
  window.location.replace("birth_list.php");
  </script>';

}else{
  echo '<script> alert("Data Update Fail")</script>';
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update page</title>
    <link rel="stylesheet" href="../member/css/birth.css">
</head>
<body> 
<div class="container">
<div class="box">
    <form action="birth_update.php?birth_id=<?php echo $row['birth_id'] ?>" method="POST">
   

    <label for="First_name">First Name</label>
            <input type="text" id="First_name" name="First_name" value= "<?php echo  $row['First_name'];?>" > <br> <br>

            <label for="Last_name">Last name</label>
            <input type="text" id="Last_name" name="Last_name" value= "<?php echo  $row['Last_name'];?>" placeholder="Enter Name"><br> <br>

            <label for="Father_name">Father name</label>
            <input type="text" id="Father_name" name="Father_name" value= "<?php echo  $row['Father_name'];?>" placeholder="Enter Name"><br> <br>

            <label for="Mother_name">Mother name</label>
            <input type="text" id="Mother_name" name="Mother_name" value= "<?php echo  $row['Mother_name'];?>" placeholder="Enter Name"><br> <br>

            <label for="Gender">Gender</label>
            <input type="text" id="Gender" name="Gender" value= "<?php echo  $row['Gender'];?>" placeholder="Enter Name"><br> <br>

            <label for="Dateofbirth">Date of birth</label>
            <input type="text" id="Dateofbirth" name="Dateofbirth" value= "<?php echo  $row['Dateofbirth'];?>" placeholder="Enter Name"><br> <br>

            <label for="Birthplace">Birth place</label>
            <input type="text" id="Birthplace" name="Birthplace" value= "<?php echo  $row['Birthplace'];?>" placeholder="Enter Name"><br> <br>

            <label for="premanent">Premanent Address</label>
            <input type="text" id="premanent" name="premanent" value= "<?php echo  $row['premanent'];?>" placeholder="Enter Name"><br><br>

            <label for="postal">Postal Address</label>
            <input type="text" id="postal" name="postal" value= "<?php echo  $row['postal'];?>" placeholder="Enter Name"><br><br>
            <label for="guardian">guardian</label>
            <input type="text" id="guardian" name="guardian" value= "<?php echo  $row['guardian'];?>" placeholder="Enter Name"><br><br>

            <label for="rela_guardian">relationship guardian</label>
            <input type="text" id="rela_guardian" name="rela_guardian" value= "<?php echo  $row['rela_guardian'];?>" placeholder="Enter Name"><br><br>


 
    <button type="submit" class="registerbtn"  name="submit">Update</button>
 
</form>
</div>
</div>
</body>
</html>