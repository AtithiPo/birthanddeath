<?php
include '../connect.php';
 

if(isset($_GET['birth_id'])){

$birth_id = $_GET['birth_id'];

$query ="DELETE from birthform WHERE birth_id='$birth_id'";

$result = mysqli_query($conn,$query);
if($result){
    echo '<script> alert("Data Deleted")</script>';
    header('location:birth_list.php');


}else{
    echo '<script> alert("Data delete Fail")</script>';
}
}


?>