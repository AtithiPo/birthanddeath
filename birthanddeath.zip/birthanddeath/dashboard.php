<?php
session_start();

if (!isset($_SESSION['email'])) {
	header('location:login.php');
}



?>


<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,
				initial-scale=1.0">
	<title>Admin Dashboard</title>
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/responsive.css">
</head>

<body>

	<!-- for header part -->
	<header>

		<div class="logosec">
			<div class="logo">Admin</div>
			<img src="image/3_line.png" class="icn menuicn" id="menuicn" alt="menu-icon">
		</div>

		<div class="searchbar">
			<input type="text" placeholder="Search">
			<div class="searchbtn">
				<img src="image/search.png" class="icn srchicn" alt="search-icon">
			</div>
		</div>

		<div class="message">
			<div class="circle"></div>
			<img src="image/notification.png" class="icn" alt="">
			<div class="dp">
				<img src="image/profile.png" class="dpicn" alt="dp">
			</div>
		</div>

	</header>

	<div class="main-container">
		<div class="navcontainer">
			<nav class="nav">
				<?php include('./user/side_bar.php')  ?>

			</nav>
		</div>
		<div class="main">

			<div class="searchbar2">
				<input type="text" name="" id="" placeholder="Search">
				<div class="searchbtn">
					<img src="image/search_icon.png" class="icn srchicn" alt="search-button">
				</div>
			</div>

			<!-- <div class="box-container">

				<div class="box box1">
					<div class="text">
						<h2 class="topic-heading">5</h2>
						<h2 class="topic">Order View</h2>
					</div>

					<img src="image/eye.png" alt="Views">
				</div>

				<div class="box box2">
					<div class="text">
						<h2 class="topic-heading">55</h2>
						<h2 class="topic">total order</h2>
					</div>

					<img src="image/like.png" alt="likes">
				</div>

				<div class="box box3">
					<div class="text">
						<h2 class="topic-heading">3</h2>
						<h2 class="topic">pending order</h2>
					</div>

					<img src="image/wall-clock.png" alt="comments">
				</div>




			</div> -->

		</div>
	</div>

	<script src="Js/index.js"></script>
</body>

</html>