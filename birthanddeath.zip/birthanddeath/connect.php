<?php
$HOSTNAME= 'localhost';
$USERNAME= 'root';
$PASSWORD= '';
$DATABASE = 'birthanddeath';
$conn = new mysqli($HOSTNAME, $USERNAME, $PASSWORD, $DATABASE);
IF ($conn->connect_error){
    die("Connection faild");
} 

if(isset($_SESSION['email'])){
    $email = $_SESSION['email'];

    $sql = "SELECT admin_id, full_name, email FROM admin where email = '$email'";
    $result = $conn->query($sql);
    $users = $result -> fetch_assoc();
}


?>