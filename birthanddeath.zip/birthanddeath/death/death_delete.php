<?php
include '../connect.php';
 

if(isset($_GET['id'])){

$id = $_GET['id'];

$query ="DELETE from deathform WHERE id='$id'";

$result = mysqli_query($conn,$query);
if($result){
    echo '<script> alert("Data Deleted")</script>';
    header('location:death_list.php');


}else{
    echo '<script> alert("Data delete Fail")</script>';
}
}


?>