<?php

include '../connect.php';
if(is_numeric($id =$_GET['id'])){
  $id =$_GET['id'];
} else{
  header('location:death_list.php');
}


$qury="SELECT * FROM deathform WHERE id='$id'";
$result = $conn->query($qury);
$row = $result->fetch_assoc(); 




if(isset($_POST['submit'])){
$fname=  $_POST['fname'];
$lname =  $_POST['lname'];
$gender =  $_POST['gender'];
$dateofbirth =  $_POST['dateofbirth'];
$dateofdeath =  $_POST['dateofdeath'];
$age =  $_POST['age'];
$cause =  $_POST['cause'];
$country =  $_POST['country'];
$province =  $_POST['province'];
$municipality =  $_POST['municipality'];
$ward =  $_POST['ward'];
$guardian =  $_POST['guardian'];
$rela_guardian =  $_POST['rela_guardian'];
$sql ="UPDATE deathform SET fname='$fname', lname='$lname',gender='$gender',dateofbirth='$dateofbirth',dateofdeath='$dateofdeath',age='$age',cause='$cause',
country='$country',province='$province',municipality='$municipality',ward='$ward',guardian='$guardian',rela_guardian='$rela_guardian' WHERE id= '$id'";
$result=mysqli_query($conn,$sql);
print_r($result);
if($result){
  //echo '<script> alert("Data Update")</script>';
  echo '<script> window.alert("Succesfully Updated");
  window.location.replace("death_list.php");
  </script>';

}else{
  echo '<script> alert("Data Update Fail")</script>';
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update page</title>
    <link rel="stylesheet" href="../member/css/birth.css">
</head>
<body> 
<div class="container">
<div class="box">
    <form action="death_update.php?id=<?php echo $row['id'] ?>" method="POST">
    <div class="submenu">
    <label for="fname">First Name*</label>
    <input type="text" id="fname" name="fname"  value= "<?php echo  $row['fname'];?>" placeholder="Enter first name..."><br><br>

    <label for="lname">Last Name*</label>
    <input type="text" id="lname" name="lname"  value= "<?php echo  $row['lname'];?>" placeholder="Enter last name..."><br><br>

    <label for="gender">Gender*</label>
    <input type="text" id="gender" name="gender" value= "<?php echo  $row['gender'];?>" placeholder="Enter Name"><br> <br>

    <label for="dateofbirth">Date of Birth:</label>
    <input type="date" id="dateofbirth" name="dateofbirth"  value= "<?php echo  $row['dateofbirth'];?>"><br><br>

    <label for="dateofdeath">Date of Death:</label>
    <input type="date" id="dateofdeath" name="dateofdeath"  value= "<?php echo  $row['dateofdeath'];?>"><br><br>

    <label for="age">Age</label>
    <input type="number" name="age"  value= "<?php echo  $row['age'];?>"><br><br>

    <label for="cause">Causes of Death</label>
    <input type="text" id="cause" name="cause"  value= "<?php echo  $row['cause'];?>" placeholder="Enter cause of death"><br><br>

    <label for="country">Country</label>
    <input type="text" id="country" name="country"   value= "<?php echo  $row['country'];?>" placeholder="Enter country"><br><br>

    <label for="province">Province</label>
    <select id="province" name="province"  value= "<?php echo  $row['province'];?>" >
      <option value="Province-1">Province-1</option>
      <option value="Province-2">Province-2</option>
      <option value="Province-3">Province-3</option>
      <option value="Province-4">Province-4</option>
      <option value="Province-5">Province-5</option>
      <option value="Province-6">Province-6</option>
      <option value="Province-7">Province-7</option>
    </select><br><br>

    <label for="municipality">Municipality</label>
    <input type="text" name="municipality"  value= "<?php echo  $row['municipality'];?>"  placeholder="Enter municipality"><br><br>

    <label for="ward">Ward</label>
    <input type="number" name="ward"  value= "<?php echo  $row['ward'];?>"><br><br>

    <label for="guardian">Family member who provided the details of death</label>
    <input type="text" id="guardian" name="guardian"  value= "<?php echo  $row['guardian'];?>" placeholder="Enter name of the family member..."><br><br>

    <label for="rela_guardian">Relationship with death person</label>
    <input type="text" id="rela_guardian" name="rela_guardian"  value= "<?php echo  $row['rela_guardian'];?>" placeholder="Enter relationship with death person..."><br><br>
    
    <!-- <label for="full_name">Full Name</label>
            <input type="text" id="fname" name="full_name" value= "<?php echo  $row['full_name'];?>" placeholder="Enter Name">
  
   
            <label for="email">E-mail</label>
            <input type="text" id="lname" name="email" value="<?php echo $row['email']; ?>" placeholder="Your Email"> -->


 
    <button type="submit" class="registerbtn"  name="submit">Update</button>
  </div>
</form>
</div>
</div>
</body>
</html>